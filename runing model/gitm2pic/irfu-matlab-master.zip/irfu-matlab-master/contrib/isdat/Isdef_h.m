%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Structure like implementation in matlab
% Isdef_h

% IsTime Index
time_s=1;
time_ns=2;
IsTimeIndex=[time_s time_ns];

% IsTimePeriod Index
time_per_start = 1;
time_per_interval = 2;
IsTimePeriodIndex = [time_per_start time_per_interval];
